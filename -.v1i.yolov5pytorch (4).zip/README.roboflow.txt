
헷 - v1 2022-07-07 11:02pm
==============================

This dataset was exported via roboflow.ai on July 7, 2022 at 2:03 PM GMT

It includes 237 images.
Barley-rice-starpotato-noodle-soup-shrimp are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Randomly crop between 0 and 20 percent of the image


